const express = require('express');
const app = express();

// Middleware to read form data
app.use(express.urlencoded({ extended: true }));

// Set EJS as view engine
app.set('view engine', 'ejs');

// Home route
app.get('/', (req, res) => {
    res.render('index');
});

// Form submission route
app.post('/submit', (req, res) => {
    const data = {
        fullname: req.body.fullname,
        email: req.body.email,
        age: req.body.age,
        gender: req.body.gender,
        course: req.body.course
    };

    res.render('result', data);
});

// Start server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
