const express = require('express');
const app = express();

app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

// Temporary server-side storage
const users = [];

app.get('/', (req, res) => {
    res.render('index');
});

app.post('/submit', (req, res) => {
    const { fullname, email, age } = req.body;

    // Server-side validation
    if (!fullname || !email || !age) {
        return res.send("Server Error: All fields are required");
    }

    if (age < 18) {
        return res.send("Server Error: Age must be 18 or above");
    }

    // Store validated data
    users.push({ fullname, email, age });

    res.render('result', {
        fullname,
        email,
        age
    });
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
